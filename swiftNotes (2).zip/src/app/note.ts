export class Note {
    id: number = 0;
    title: string = '';
    content: string = '';
    constructor() {
    }
}